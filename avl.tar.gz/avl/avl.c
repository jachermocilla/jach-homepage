#include <stdio.h>
#include <stdlib.h>
	
#include "avl.h"

AVLNode 	AVLNode_new(ElementType data){
		AVLNode n = (AVLNode)malloc(sizeof(struct _AVLNode));
		n->data = data;
		n->leftSubtree = AVL_new();		/* Create null trees for left and right subtrees*/
		n->rightSubtree = AVL_new();
		return n;
}


AVL	AVL_new(){
		AVL  avl = malloc(sizeof(AVL));
		*avl = NULL;
		return avl;
}


AVLNode	AVL_find(AVL avl, ElementType data, CompareFunction cf){
		/* Start with the root */
		AVLNode t = AVL_getRoot(avl);
	
		if (t == NULL)
			return NULL;
		else if (cf(data,t->data) < 0 )
			return AVL_find(t->leftSubtree,data,cf);
		else if (cf(data,t->data) > 0 )
			return AVL_find(t->rightSubtree,data,cf);
		else
			return t;
}

AVLNode		AVL_findMin(AVL avl){
		/* Start with the root */
		AVLNode t = AVL_getRoot(avl);	
	
		if (t == NULL)
			return NULL;
		else{
			if (AVL_getRoot(t->leftSubtree) == NULL)
				return t;
			else
				return AVL_findMin(t->leftSubtree);
		}
}


AVLNode		AVL_findMax(AVL avl){
		/* Start with the root */
		AVLNode t = AVL_getRoot(avl);
	
		if (t == NULL)
			return NULL;
		else{
			if (AVL_getRoot(t->rightSubtree) == NULL)
				return t;
			else
				return AVL_findMax(t->rightSubtree);
		}
}

void		AVL_insert(AVL avl, ElementType data,CompareFunction cf){
		/* Start with the root*/
		AVLNode t = AVL_getRoot(avl);

		if (t == NULL){
			t = AVLNode_new(data);
			AVL_setRoot(avl,t);
		}else{
			if (cf(data,t->data) < 0){
				AVL_insert(t->leftSubtree,data,cf);
			}
			else if (cf(data, t->data) > 0){
				AVL_insert(t->rightSubtree,data,cf); 
			}
		}
}

void		AVL_delete(AVL avl, void *data, CompareFunction cf){
		/* Start with the root */
		AVLNode t = AVL_getRoot(avl),tmp;

		if ((AVL_getRoot(t->leftSubtree) == NULL) && (AVL_getRoot(t->rightSubtree) == NULL)){
			free(t);
			t = NULL;
		}
		else 
		if(cf(data,t->data) == 0){
			if (AVL_getRoot(t->leftSubtree) == NULL){
				tmp = t;
				t = AVL_getRoot(t->rightSubtree);
				free(tmp);
			}else if (AVL_getRoot(t->rightSubtree) == NULL){
				tmp = t;
				t = AVL_getRoot(t->leftSubtree);
				free (tmp);
			}else{
				tmp = AVL_findMin(t->rightSubtree);
				t->data = tmp->data;
				AVL_delete(t->rightSubtree,data,cf);
			}
		}else if (cf(data,t->data) < 0){
			AVL_delete(t->leftSubtree,data,cf);
		}else{
			AVL_delete(t->rightSubtree,data,cf);
		}
		AVL_setRoot(avl,t);
}


AVLNode AVL_getRoot(AVL avl){
	if (avl != NULL)
		return *avl;
	else
		return NULL;
}

void AVL_setRoot(AVL avl, AVLNode root){
	if (avl != NULL){
		*avl=root;
	}
}


void	AVL_display(AVL avl,VisitFunction vf){
	avl_display(avl,0,vf);
}

void avl_display(AVL avl,int depth, VisitFunction vf){
	int i;
	/* Start with the root */
	AVLNode t =AVL_getRoot(avl);
	
	if (t != NULL){

		for (i = 0; i < depth - 1; i++)
			printf("|  ");
		
		if (depth != 0)
			printf("+--");
	
		vf(t,t);
		avl_display(t->leftSubtree,depth + 1, vf);
		avl_display(t->rightSubtree,depth + 1, vf);
	}
}


void *AVL_getNodeData(AVLNode node){
	if (node != NULL)
		return node->data;
	return NULL;
}

void	AVL_inorder(AVL avl, AVLNode node, VisitFunction vf){
	if (node != NULL){
		AVL_inorder(avl,AVL_getRoot(node->leftSubtree),vf);
		(*vf)(avl,node);
		AVL_inorder(avl,AVL_getRoot(node->rightSubtree),vf);
	}
}

void	AVL_preorder(AVL avl, AVLNode node, VisitFunction vf){
	if (node != NULL){
		(*vf)(avl,node);
		AVL_preorder(avl,AVL_getRoot(node->leftSubtree),vf);
		AVL_preorder(avl,AVL_getRoot(node->rightSubtree),vf);
	}
}

void	AVL_postorder(AVL avl, AVLNode node, VisitFunction vf){
	if (node != NULL){
		AVL_postorder(avl,AVL_getRoot(node->leftSubtree),vf);
		AVL_postorder(avl,AVL_getRoot(node->rightSubtree),vf);
		(*vf)(avl,node);
	}
}


