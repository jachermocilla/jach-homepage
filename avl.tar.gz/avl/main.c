#include <stdio.h>

#include "wrapper.h"

#include "avl.h"

#define N 8

int visit(AVL avl,AVLNode node){
	Integer i;

	if (node != NULL){
		i = (Integer)node->data;
		printf("%d\n",i->data);
	}else
		puts("NULL NODE");
	
	return 0;
}

int visit2(AVL avl,AVLNode node){
	Integer i;

	if (node != NULL){
		i = (Integer)node->data;
		printf("%d ",i->data);
	}else
		puts("NULL NODE");
	
	return 0;
}

int compare(void *n1, void *n2){
	int retval;
	Integer I = (Integer)n1;
	Integer J = (Integer)n2;
	
	int i=I->data,j = J->data;
	
	if (i < j){
/*		printf("%d < %d\n",i,j);  */
		retval = -1;
	}
	else if(i == j){
/* 		printf("%d = %d\n",i,j);  */
			retval =  0;
	}
	else{
/* 		printf("%d > %d\n",i,j); */
		retval = 1;
	}
	return retval;
}

int main(){
	int n;

	AVL avl = NULL;
	AVLNode nmin,nmax;
	Integer Min,Max;

	avl = AVL_new();
/*
	AVL_insert(avl,Integer_new(5),compare);
	AVL_insert(avl,Integer_new(3),compare);
	AVL_insert(avl,Integer_new(7),compare);
	AVL_insert(avl,Integer_new(2),compare);
	AVL_insert(avl,Integer_new(4),compare);
	AVL_insert(avl,Integer_new(6),compare);
	AVL_insert(avl,Integer_new(8),compare);
	AVL_insert(avl,Integer_new(1),compare);
*/



	puts("Inserting...");
	AVL_insert(avl,Integer_new(1),compare);
	AVL_insert(avl,Integer_new(2),compare);
	AVL_insert(avl,Integer_new(3),compare);
	AVL_insert(avl,Integer_new(4),compare);
	AVL_insert(avl,Integer_new(5),compare);
	AVL_insert(avl,Integer_new(6),compare);
	AVL_insert(avl,Integer_new(7),compare);


	puts("Displaying...");
	AVL_display(avl,visit);



	printf("Preorder...\n");
	AVL_preorder(avl,*avl,visit2);
	printf("\nInorder...\n");
	AVL_inorder(avl,*avl,visit2);
	printf("\nPostorder...\n");
	AVL_postorder(avl,*avl,visit2);


	printf("\ndeleting 1\n");
	AVL_delete(avl,Integer_new(1),compare);
	
	AVL_display(avl,visit);
	
	printf("deleting 7\n");
	AVL_delete(avl,Integer_new(7),compare);
	
	AVL_display(avl,visit);
	

	nmin = (AVLNode)AVL_findMin(avl);
	nmax = (AVLNode)AVL_findMax(avl);

	Min = nmin->data;
	Max = nmax->data;

	
	printf("Maximum: %d\n",Max->data);
	printf("Minimum: %d\n",Min->data);


	printf("Searching for 6...\n");
	nmin = (AVLNode)AVL_find(avl,Integer_new(6),compare);
	
	if (nmin != NULL){
		Min = nmin->data;
		printf("%d found\n",Min->data);
	}else{
		printf("%d not found!\n",n);
	}
	



	return 0;
}

