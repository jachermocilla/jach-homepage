#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define _USE_ARRAY_LIST_
#include "list.h"
#include "wrapper.h"

#define TRUE 1
#define FALSE 0


typedef struct _Account{
	char name[255];
	char password[255];
}*Account;


Account Account_new(char *name,char *password){
	Account acc = malloc(sizeof(struct _Account));
	strcpy(acc->name,name);
	strcpy(acc->password,password);
	return acc;
}


int main(){
	List users = NULL;
	users = List_new();
	char buffer[255],command[255] = "";
	char *name,*pass,n[255],p[255];
	FILE *fp;
	Account acc = NULL;
	int found=FALSE;
	
	char *motd = {"UPLB Linux release 1.0 (mudspring)\nKernel 2.4.20 on an i686\n\n"};


	/*
    * Read the password file and store information in a list
    */
	fp = fopen("passwd.txt","r");
	while((fgets(buffer,255,fp)) != NULL){
		buffer[strlen(buffer) - 1] = '\0';
		name = strtok(buffer,":");
		pass = strtok(NULL,":");
		if (pass != NULL && name != NULL)
			List_insert(users,List_end(users),Account_new(name,pass));
	}
		
	printf("%s",motd);

	while (!found){
		printf("booch login: ");
		scanf("%s",n);
		printf("Password: ");
		scanf("%s",p);

		/* Perform a linear search on the users list 
       * To check if the user is valid.
       */
		ListIterator iter;
		for(iter=List_begin(users);iter != List_end(users);iter = List_next(iter)){
			acc = List_elementAt(users,iter);
			if ((strcmp(acc->name,n) == 0) && (strcmp(acc->password,p)==0)){
				found=TRUE;
				break;
			}
		}

		if (!found)
			puts("Login incorrect\n");
		else
			break;		
	}

	printf("\nType 'exit' to quit.\n");

	while (strcmp(command,"exit") != 0){
		printf("\n[%s@booch:~ ]$ ",n);
		fgets(command,255,stdin);
		command[strlen(command) - 1] = '\0';
		if ( strcmp(command,"exit") != 0)
			printf("bash: %s :command not found\n",command);
	}
	puts("Shutting down...");
	
	return 0;
}





