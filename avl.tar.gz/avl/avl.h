#ifndef __AVL_H_
#define __AVL_H_

#include "types.h"

/**
 * Binary Search Trees
 */


/* Forward Declarations */	
typedef struct _AVLNode *AVLNode;

/*Note that the AVL is a pointer to AVLNode*/
typedef AVLNode *AVL;


/* Type definitions for pointers to functions */
typedef int (*VisitFunction)(AVL, AVLNode);
typedef int (*CompareFunction)(void *, void *);


/**
 * A AVL node
 */
struct _AVLNode {
	ElementType data;			/* Data on the node */
	AVL leftSubtree;			/* Points to the left subtree */
	AVL rightSubtree;			/* Points to the right subtree */
	int height;
};


/**
 * Returns a new AVLNode
 */
AVLNode		AVLNode_new(ElementType data);

/*
 * Returns a new AVL or a pointer to a AVLNode
 */
AVL			AVL_new();

/* 
 * Returns the AVLNode that containts [data]
 * [cf] is a CompareFunction that tests equality, see above
 */
AVLNode		AVL_find(AVL avl, ElementType data, CompareFunction cf);

/**
 * Returns the AVLNode that has the minimum 
 */
AVLNode		AVL_findMin(AVL avl);

/*
 * Returns the AVLNode that has the maximum
 */
AVLNode		AVL_findMax(AVL avl);

/*
 * Inserts [data] on [avl] maintaining the AVL property.
 * You have to create the AVLNode inside this function.
 * [cf] is a compare function for equality checking (<,=,>).
 */
void			AVL_insert(AVL avl, ElementType data, CompareFunction cf);

/**
 * Deletes [data] from the [avl]. [cf] is a compare function 
 */

void			AVL_delete(AVL avl, ElementType data, CompareFunction cf);

/* Returns the root node of [avl]*/
AVLNode 	AVL_getRoot(AVL avl);

/* Sets the [root] node of [avl]*/
void 		 	AVL_setRoot(AVL avl, AVLNode root);


/* Display the contents of the AVL */
void			AVL_display(AVL avl, VisitFunction vf);
void			avl_display(AVL avl , int depth, VisitFunction vf);


/*
 * Returns the data on a AVL node
 */
ElementType 	AVL_getNodeData(AVLNode node);


/* Generic binary tree traversals */
void			AVL_preorder(AVL avl, AVLNode node, VisitFunction vf);
void			AVL_inorder(AVL avl, AVLNode node, VisitFunction vf);
void			AVL_postorder(AVL avl, AVLNode node, VisitFunction vf);

#endif




