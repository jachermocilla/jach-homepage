#include <stdlib.h>
#include <stdio.h>

#ifndef __LIST_H__
#define __LIST_H__

/**
 * Define the data that we can put in a list. 
 * A pointer to void type means that we can put
 * any type of data on the list using a pointer
 */

#include "types.h"


/**
 * Since a list is an ADT, it can have several
 * implementations. Implementation specific 
 * definitions are put inside their own #ifdef block
 */

/* For doubly linked list implementation */
#ifdef _USE_DOUBLY_LINKED_LIST_
typedef struct _ListNode 	*ListIterator;
typedef struct _ListNode 	*ListNode;
typedef struct _List			*List;

struct _ListNode {
	ElementType data;		/* The data on the node */
	ListNode next;			/* Pointer to next item */
	ListNode prev;			/* Pointer to prev item */
};

struct _List {
	int n;					/*	The current number of nodes in the list */
	ListNode head;			/* Points to the first element in the list */
	ListNode tail;			/* Points to the last element in the list */
};

/* Helper function to create a new node */
ListNode ListNode_new(void *data);
#endif

/* For array specific implementation */
#ifdef _USE_ARRAY_LIST_
#define MAXITEMS 1000
typedef int ListIterator;
typedef struct _List	*List;
struct _List {
	int n;
	ElementType data[MAXITEMS];
};
#endif

/*-- LIST ADT Interface: Not implementation specific -- */
/**
 * In order to make the interface really independent of implementation,
 * the concept of an iterator is used. The iterator "points" to a particular
 * item in the list (or position).In the case of linked list implementation, an
 * iterator is a pointer to a node. In array implementation, an iterator
 * is an index(an int) in the array. See above #ifdef blocks.
 */

/**
 * Returns a new list after allocating memory.
 */
List	List_new();

/**
 * Inserts [data] at position [pos] of "list".
 */
void 	List_insert(List list, ListIterator pos, ElementType data);

/** 
 * Destroys [list] by freeing up memory.
 * 
 */
void  List_free(List *list);

/**
 * Removes the item at [pos] from [list].
 */
void	List_remove(List list, ListIterator pos);

/**
 * Returns the item at [pos] of [list]
 */
ElementType List_elementAt(List list, ListIterator pos);


/**
 * Returns an iterator for the beginning of [list].
 */
ListIterator List_begin(List list);

/**
 * Returns an iterator for the end of [list].
 */
ListIterator List_end(List list);

/**
 * Returns an iterator for the last item in the [list].
 */
ListIterator List_last(List list);

/**
 * Returns an iterator for the next item relative
 * to element at [pos]. 
 */
ListIterator List_next(ListIterator pos);

/**
 * Returns an iterator for the previous element
 * relative to element at [pos].
 */
ListIterator List_prev(ListIterator pos);

/**
 * Returns the number of items in [list].
 */
int List_size(List list);

/**
 * Returns 1 if [list] is empty, 0 otherwise.
 * An empty list is one with no items in it.
 */
int List_isEmpty(List list);

/**
 * Prints a elements of the list.
 * This function iterates over the items in the
 * list and calls the [print] function for each item.
 */
void List_print(List list, void (*print)(ElementType));





#endif


