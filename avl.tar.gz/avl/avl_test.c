#include <stdio.h>
#include <stdlib.h>
#include <CUnit/Basic.h>

#include "avl.h"
#define _USE_ARRAY_LIST_
#include "list.h"
#include "wrapper.h"

/* Global Data */
AVL avl;
List list;


/* Visit function to print the contents of a node */
int visit(AVL avl,AVLNode node){
	String s;

	if (node != NULL){
		s = (String)node->data;
		printf("%s\n",s->data);
	}else
		puts("NULL NODE");
	return 0;
}


/* Visit function to store nodes visited 
 * Used in traversals
 */
int store(AVL avl, AVLNode node){
	String s;
	if (node != NULL){
		s = (String)node->data;
		//printf("%s\n",s->data);
		List_insert(list,List_end(list),s);
	}else
		puts("NULL NODE");
	return 0;
		
}


/* Compare function */
int compare(void *str1, void *str2){
	String s1 = (String)str1;
	String s2 = (String)str2;
	return strcmp(s1->data,s2->data);
}


void 	test_AVL(){
	int i;

	char babes[5][10]={"Katrina","Ehra","Angel","Marian","Christine"};

	char preorder[5][10]={"Katrina","Ehra","Angel","Christine","Marian"};
	char inorder[5][10]={"Angel","Christine","Ehra","Katrina","Marian"};
	char postorder[5][10]={"Christine","Angel","Ehra","Marian","Katrina"}; 
	char nokat[5][10]={"Angel","Christine","Ehra","Marian"};

	avl = AVL_new();

/*	printf("Testing now...\n");
	
	printf("Testing insert...\n"); */
	for (i=0;i<5;i++)
		AVL_insert(avl,String_new(babes[i]),compare);

/*	printf("Testing Display...\n");*/
	/*AVL_display(avl,visit);*/

	/*printf("Preorder-------\n");*/
	list = List_new();
	AVL_preorder(avl,*avl,store);
	ListIterator p;
	i=0;
	for (p=List_begin(list); p != List_end(list); p = List_next(p)){
		String s=List_elementAt(list,p);
		CU_ASSERT(strcmp(preorder[i++],s->data)==0);
	}


	/*printf("Inorder--------\n");*/
	list = List_new();
	AVL_inorder(avl,*avl,store);
	i=0;
	for (p=List_begin(list); p != List_end(list); p = List_next(p)){
		String s=List_elementAt(list,p);
		CU_ASSERT(strcmp(inorder[i++],s->data)==0);
	}

/*	printf("Postorder--------\n");*/
	list = List_new();
	AVL_postorder(avl,*avl,store);
	i=0;
	for (p=List_begin(list); p != List_end(list); p = List_next(p)){
		String s=List_elementAt(list,p);
		CU_ASSERT(strcmp(postorder[i++],s->data)==0);
	}


	/*Test for find */
	AVLNode result = AVL_find(avl,String_new("Ehra"),compare);
	CU_ASSERT(result != NULL);
	result = AVL_find(avl,String_new("Diana"),compare);
	CU_ASSERT(result == NULL);

	/*Test for find min*/
	result = AVL_findMin(avl);
	CU_ASSERT(result != NULL);
	String str = AVL_getNodeData(result); 
	CU_ASSERT(strcmp(inorder[0],str->data) == 0);
	
	/*Test for find max*/
	result = AVL_findMax(avl);
	CU_ASSERT(result != NULL);
	str = AVL_getNodeData(result); 
	CU_ASSERT(strcmp(inorder[4],str->data) == 0);

	/*Test for DELETE */


	AVL_delete(avl,String_new("Katrina"),compare);	
	list = List_new();
	AVL_inorder(avl,*avl,store);
	i=0;
	for (p=List_begin(list); p != List_end(list); p = List_next(p)){
		String s=List_elementAt(list,p);
		CU_ASSERT(strcmp(nokat[i++],s->data)==0);
	}

	


}


int init_suite1(void){
	avl = AVL_new();
	return 0;
}

int clean_suite1(void){
	return 0;
}

int main(){
	CU_pSuite pSuite = NULL;

   /* initialize the CUnit test registry */
   if (CUE_SUCCESS != CU_initialize_registry())
		return CU_get_error();

	/* add a suite to the registry */
   pSuite = CU_add_suite("Exercise 4 - AVL", init_suite1, clean_suite1);	

	if (NULL == pSuite) {
		CU_cleanup_registry();
		return CU_get_error();
   }

	/* add test to suite */
	if ((NULL == CU_add_test(pSuite, "AVL", test_AVL))){
		CU_cleanup_registry();
      return CU_get_error();
	}
	
	/* run the tests*/
	CU_basic_set_mode(CU_BRM_VERBOSE);
   CU_basic_run_tests();
   CU_cleanup_registry();
   return CU_get_error();
}
