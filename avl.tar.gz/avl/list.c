#include <stdlib.h>
#include <stdio.h>

/* #define _USE_DOUBLY_LINKED_LIST_ */
#define _USE_ARRAY_LIST_ 
#include "list.h"


#ifdef _USE_DOUBLY_LINKED_LIST_
List	List_new(){
	List list = (List)malloc(sizeof(struct _List));
	list->n = 0;
	list->head = NULL;
	list->tail = NULL;
	return list;
}

ListNode ListNode_new(void *data){
	ListNode node = (ListNode)malloc(sizeof(struct _ListNode));
	node->data = data;
	node->prev = NULL;
	node->next = NULL;
	return node;
}

void 	List_insert(List list, ListIterator pos, ElementType data){
}


void  List_free(List *list){}

void	List_remove(List list, ListIterator pos){
}

ElementType List_elementAt(List list, ListIterator pos){
}

ListIterator List_begin(List list){
}

ListIterator List_end(List list){
	return (NULL);
}

ListIterator List_last(List list){
	return (list->tail);
}

ListIterator List_next(ListIterator pos){
}


ListIterator List_prev(ListIterator pos){
}

int List_size(List list){
}


int List_isEmpty(List list){
}

void List_print(List list, void (*print)(ElementType)){
	ListIterator p;
	for (p=List_begin(list); p != List_end(list); p = List_next(p)){
		print(List_elementAt(list,p));
	}
}

#endif



#ifdef _USE_ARRAY_LIST_
/* -------------------------------------------------------- */
List	List_new(){
	int i;
	List list = (List)malloc(sizeof(struct _List));
	list->n=0;
	for (i = 0; i < 1000;i++)
		list->data[i] = NULL;	
	return list;
}

/* -------------------------------------------------------- */
void 	List_insert(List list, ListIterator pos, ElementType data){
	int i;
	if (list->data[pos] == NULL){
		list->data[pos]=data;
		list->n++;
	}else{ 
		if (list->n < (MAXITEMS-1)){
			for (i = list->n; i >= (int)pos; i--){
				list->data[i] = list->data[i-1];
			}
			list->data[pos] = data;
			list->n++;
		} 
	}
}
/* -------------------------------------------------------- */

void  List_free(List *list){
	free(list);
}
/* -------------------------------------------------------- */

void	List_remove(List list, ListIterator pos){
	int i = 0;
	if (pos < list->n){
		list->n = list->n-1;
		for (i=pos;i<list->n;i++){
			list->data[i]=list->data[i+1];
		}
	}
}
/* -------------------------------------------------------- */

ElementType List_elementAt(List list, ListIterator pos){
	return list->data[pos];
}
/* -------------------------------------------------------- */

ListIterator List_begin(List list){
	return 0;
}
/* -------------------------------------------------------- */

ListIterator List_end(List list){
	return list->n;
}
/* -------------------------------------------------------- */

ListIterator List_last(List list){
	return list->n-1;
}
/* -------------------------------------------------------- */

ListIterator List_next(ListIterator pos){
	return pos+1;
}

/* -------------------------------------------------------- */

ListIterator List_prev(ListIterator pos){
	return pos-1;
}

/* -------------------------------------------------------- */

int List_size(List list){
	return list->n;
}

/* -------------------------------------------------------- */

int List_isEmpty(List list){
	return (list->n == 0)?1:0;
}

/* -------------------------------------------------------- */

void List_print(List list, void (*print)(ElementType)){
	ListIterator p;
	for (p=List_begin(list); p != List_end(list); p = List_next(p)){
		print(List_elementAt(list,p));
	}
}
/* -------------------------------------------------------- */
#endif







