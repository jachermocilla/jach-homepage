#ifndef __TYPES_H__
#define __TYPES_H__

typedef void *ElementType;

#endif
