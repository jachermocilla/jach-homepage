#include <stdio.h>

#include "matrix.h"

int main(){
	printf("Write your own tests inside main.c\n");
	return 0;
}
