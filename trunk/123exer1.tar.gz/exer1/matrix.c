#include <stdlib.h>
#include <stdio.h>
#include "matrix.h"

Matrix Matrix_new(int rows, int columns){
	Matrix a = (Matrix)malloc(sizeof(_Matrix));
	int row,column;
	if (a != NULL){
		a->rows = rows;
		a->columns = columns;
		for (row=0; row < rows; row++)
			for (column=0; column < columns; column++)
				a->data[row][column] = 0; 
	}
	return a;
}

void Matrix_free(Matrix a){
	free(a);
}

void Matrix_print(Matrix a){
	int r,c;
	printf("\n");
	for (r = 0; r < a->rows; r++){
		for (c = 0; c < a->columns; c++){
			printf("%4.2f ", a->data[r][c]);
		}
		printf("\n");
	}
}


void Matrix_get_dim(Matrix a, int *rows, int *columns){
}

void Matrix_set(Matrix a, int row, int column, double value){
}

double Matrix_get(Matrix a, int row, int column){
}

Matrix Matrix_scalar_mul(Matrix a, double c){
}

Matrix Matrix_add(Matrix a, Matrix b){
}

Matrix Matrix_mul(Matrix a, Matrix b){
}

Matrix Matrix_transpose(Matrix a){
}


