#include <stdlib.h>

#ifndef __MATRIX_H__
#define __MATRIX_H__

#define MAXROWS 10
#define MAXCOLS 10

/**
 * Structure definition for a matrix
 */
typedef struct{
	double data[MAXROWS][MAXCOLS];
	int rows, columns;
}_Matrix, *Matrix;



/**
 * Creates a new matrix with rows and columns dimension.
 * Returns a new matrix.
 */
Matrix Matrix_new(int rows, int columns);

/**
 * Free the memory space allocated to matrix a.
 */
void Matrix_free(Matrix a);

/**
 * Returns the dimension of the matrix in rows and columns.
 */
void Matrix_get_dim(Matrix a, int *rows, int *columns);


/**
 * Sets the value at cell (row, column) of matrix a.
 */
void Matrix_set(Matrix a, int row, int column, double value);

/**
 * Returns the value at cell (row, column) of matrix a.
 */
double Matrix_get(Matrix a, int row, int column);

/**
 * Performs multiplication of scalar c with matrix a.
 * Returns a new matrix.
 */ 
Matrix Matrix_scalar_mul(Matrix a, double c);

/**
 * Add matrix a and matrix b.
 * Returns a new matrix.
 */
Matrix Matrix_add(Matrix a, Matrix b);

/**
 * Multiply matrix a and matrix b.
 * Returns a new matrix.
 */
Matrix Matrix_mul(Matrix a, Matrix b);

/**
 * Returns the transpose of a matrix as a new matrix
 * Returns a new matrix.
 */
Matrix Matrix_transpose(Matrix a);

/**
 * Displays the matrix on the screen
 */
void Matrix_print(Matrix a);

#endif
