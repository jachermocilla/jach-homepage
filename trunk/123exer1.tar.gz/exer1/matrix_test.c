#include <stdio.h>
#include <CUnit/Basic.h>

#include "matrix.h"

void test_Matrix_new(void){
	Matrix a = Matrix_new(5,4);
	int n,m;
	Matrix_get_dim(a,&n,&m);
	CU_ASSERT(a != NULL);
	CU_ASSERT(n == 5);
	CU_ASSERT(m == 4);
}

void test_Matrix_get_set(void){
	Matrix a = Matrix_new(5,4);
	double b;
	
	Matrix_set(a,3,3,4.5);
	b = Matrix_get(a,3,3);
	CU_ASSERT(a != NULL);
	CU_ASSERT(b == 4.5);
}

void test_Matrix_scalar_mul(){
	Matrix a = Matrix_new(3,2),b;
	int c = 3;
	Matrix_set(a,0,0,2);
	Matrix_set(a,0,1,1);
	Matrix_set(a,1,0,3);
	Matrix_set(a,1,1,2);
	Matrix_set(a,2,0,-2);
	Matrix_set(a,2,1,2);

	b = Matrix_scalar_mul(a,c);

	CU_ASSERT(Matrix_get(b,0,0) == 6);
	CU_ASSERT(Matrix_get(b,0,1) == 3);
	CU_ASSERT(Matrix_get(b,1,0) == 9);
	CU_ASSERT(Matrix_get(b,1,1) == 6);
	CU_ASSERT(Matrix_get(b,2,0) == -6);
	CU_ASSERT(Matrix_get(b,2,1) == 6);

} 

void test_Matrix_add(){
	Matrix a = Matrix_new(3,2),b=Matrix_new(3,2),c;
	Matrix_set(a,0,0,2);
	Matrix_set(a,0,1,1);
	Matrix_set(a,1,0,3);
	Matrix_set(a,1,1,2);
	Matrix_set(a,2,0,-2);
	Matrix_set(a,2,1,2);

	Matrix_set(b,0,0,1);
	Matrix_set(b,0,1,1);
	Matrix_set(b,1,0,4);
	Matrix_set(b,1,1,2);
	Matrix_set(b,2,0,-2);
	Matrix_set(b,2,1,1);

	c = Matrix_add(a,b);

	CU_ASSERT(Matrix_get(c,0,0) == 3);
	CU_ASSERT(Matrix_get(c,0,1) == 2);
	CU_ASSERT(Matrix_get(c,1,0) == 7);
	CU_ASSERT(Matrix_get(c,1,1) == 4);
	CU_ASSERT(Matrix_get(c,2,0) == -4);
	CU_ASSERT(Matrix_get(c,2,1) == 3);

} 

void test_Matrix_mul(){
	Matrix a = Matrix_new(3,2),d=Matrix_new(2,3),c;
	Matrix_set(a,0,0,2);
	Matrix_set(a,0,1,1);
	Matrix_set(a,1,0,3);
	Matrix_set(a,1,1,2);
	Matrix_set(a,2,0,-2);
	Matrix_set(a,2,1,2);

	Matrix_set(d,0,0,2);
	Matrix_set(d,0,1,1);
	Matrix_set(d,0,2,3);
	Matrix_set(d,1,0,-2);
	Matrix_set(d,1,1,2);
	Matrix_set(d,1,2,1);

	c = Matrix_mul(d,a);

	CU_ASSERT(Matrix_get(c,0,0) == 1);
	CU_ASSERT(Matrix_get(c,0,1) == 10);
	CU_ASSERT(Matrix_get(c,1,0) == 0);
	CU_ASSERT(Matrix_get(c,1,1) == 4);

}

void test_Matrix_transpose(){
	Matrix a = Matrix_new(3,2),b;
	Matrix_set(a,0,0,2);
	Matrix_set(a,0,1,1);
	Matrix_set(a,1,0,3);
	Matrix_set(a,1,1,2);
	Matrix_set(a,2,0,-2);
	Matrix_set(a,2,1,2);
	
	b = Matrix_transpose(a);

	CU_ASSERT(Matrix_get(b,0,0) == 2);
	CU_ASSERT(Matrix_get(b,0,1) == 3);
	CU_ASSERT(Matrix_get(b,0,2) == -2);
	CU_ASSERT(Matrix_get(b,1,0) == 1);
	CU_ASSERT(Matrix_get(b,1,1) == 2);
	CU_ASSERT(Matrix_get(b,1,2) == 2);


} 



int init_suite1(void){
	return 0;
}

int clean_suite1(void){
	return 0;
}

int main(){
	CU_pSuite pSuite = NULL;

   /* initialize the CUnit test registry */
   if (CUE_SUCCESS != CU_initialize_registry())
		return CU_get_error();

	/* add a suite to the registry */
   pSuite = CU_add_suite("Exercise 1 - Arrays ", init_suite1, clean_suite1);	

	if (NULL == pSuite) {
		CU_cleanup_registry();
		return CU_get_error();
   }

	/* add test to suite */
	if ((NULL == CU_add_test(pSuite, "Test of Matrix_new", test_Matrix_new))){
		CU_cleanup_registry();
      return CU_get_error();
	}
	
	if ((NULL == CU_add_test(pSuite, "Test of Matrix_get() and Matrix_set()", test_Matrix_get_set))){
		CU_cleanup_registry();
      return CU_get_error();
	}
	
	if ((NULL == CU_add_test(pSuite, "Test of Matrix_scalar_mul()", test_Matrix_scalar_mul))){
		CU_cleanup_registry();
      return CU_get_error();
	}

	if ((NULL == CU_add_test(pSuite, "Test of Matrix_add()", test_Matrix_add))){
		CU_cleanup_registry();
      return CU_get_error();
	}

	if ((NULL == CU_add_test(pSuite, "Test of Matrix_mul()", test_Matrix_mul))){
		CU_cleanup_registry();
      return CU_get_error();
	}

	if ((NULL == CU_add_test(pSuite, "Test of Matrix_transpose()", test_Matrix_transpose))){
		CU_cleanup_registry();
      return CU_get_error();
	}


	/* run the tests*/
	CU_basic_set_mode(CU_BRM_VERBOSE);
   CU_basic_run_tests();
   CU_cleanup_registry();
   return CU_get_error();
}
