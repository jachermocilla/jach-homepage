#include <stdlib.h>
#include <stdio.h>

#ifndef __LIST_H__
#define __LIST_H__

/* Define the data that we can put in a list. 
 * A pointer to void type means that we can put
 * any type of data on the list using a pointer
 */
typedef void *ElementType;


/**
 * Since a list is an ADT, it can have several
 * implementations. Implementation specific 
 * definitions are put inside their own #ifdef block
 */

/* For doubly linked list implementation */
#ifdef _USE_DOUBLY_LINKED_LIST_
typedef struct _ListNode 	*ListIterator;
typedef struct _List			*List;

struct _ListNode {
	ElementType data;
	ListNode *next;
	ListNode *prev;	
};

struct _List {
	int n;
	ListNode head;
	ListNode tail;
};
ListNode ListNode_new(void *data);
#endif

/* For array specific implementation */
#ifdef _USE_ARRAY_LIST_
#define MAXITEMS 1000
typedef int ListIterator;
typedef struct _List	*List;
struct _List {
	int n;
	ElementType data[MAXITEMS];
};
#endif

/*-- LIST ADT Interface: Not implementation specific -- */

/**
 * Returns a new list
 */
List	List_new();

/**
 * Inserts data at position pos of list.
 *
 * @param list The list itself.
 * @param pos  Iterator where data will be inserted
 * @param data The data to be inserted
 */
void 	List_insert(List list, ListIterator pos, ElementType data);

/** 
 * Destroys list by freeing up memory.
 * 
 * @param list The list.
 */
void  List_free(List *list);

/**
 * Removes an item at pos from list.
 */
void	List_remove(List list, ListIterator pos);

/**
 * Returns the element at pos of list
 */
ElementType List_elementAt(List list, ListIterator pos);


/**
 * Returns an iterator for the beginning of list.
 */
ListIterator List_begin(List list);

/**
 * Returns an iterator for the end of list,
 * 
 */
ListIterator List_end(List list);

/**
 * Returns an iterator for the last element of list.
 */
ListIterator List_last(List list);

/**
 * Returns an iterator for the next element relative
 * to element at pos. 
 */
ListIterator List_next(ListIterator pos);

/**
 * Returns an iterator for the previous element
 * relative to element at pos.
 */
ListIterator List_prev(ListIterator pos);

/**
 * Returns the number of elements in list.
 */
int List_size(List list);

/**
 * Returns 1 if list is empty, 0 otherwise.
 */
int List_isEmpty(List list);

/**
 * Prints a elements of the list.
 */
void List_print(List list, void (*print)(ElementType));





#endif


