#include <stdio.h>
#include <CUnit/Basic.h>

#define _USE_ARRAY_LIST_
#include "list.h"

#include "wrapper.h"

void Integer_print(ElementType e){
	Integer g = (Integer)e;
	printf("%d\n",g->data);
}


List	test_List_new(){
	List l = List_new();
	CU_ASSERT(l != NULL);
}

void 	test_List_insert(){
	int i=0;
	ListIterator p;
	Integer g;
	List l = List_new();

	int data[]={3,5,3,4,1};


	for (i = 0 ; i < 5;i++)
		List_insert(l,List_end(l),Integer_new(data[i]));


	i=0;
	for (p=List_begin(l); p != List_end(l); p = List_next(p)){
		g = (Integer)List_elementAt(l,p);
		CU_ASSERT(g->data == data[i++]);
	}
	
	
}
void  test_List_free(){
	
	CU_ASSERT(1);

}
void	test_List_remove(){
	int i=0;
	ListIterator p;
	Integer g;
	List l = List_new();

	int data[]={3,5,3,4,1};


	for (i = 0 ; i < 5;i++)
		List_insert(l,List_end(l),Integer_new(data[i]));

	p = List_begin(l);
	p = List_next(p);
	List_remove(l,p);
	p = List_begin(l);
	List_remove(l,p);
	List_remove(l,List_last(l));

	i=2;
	for (p=List_begin(l); p != List_end(l); p = List_next(p)){
		g = (Integer)List_elementAt(l,p);
		CU_ASSERT(g->data == data[i++]);
	}


}

//void 	test_List_elementAt(){CU_ASSERT(0);}
//void 	test_List_begin(){CU_ASSERT(0);}
//void	test_List_end(){CU_ASSERT(0);}
//void 	test_List_last(){CU_ASSERT(0);}
//void	test_List_next(){CU_ASSERT(0);}
//void	test_List_prev(){CU_ASSERT(0);}

void	test_List_size(){
	int i=0;
	ListIterator p;
	Integer g;
	List l = List_new();

	int data[]={3,5,3,4,1};


	for (i = 0 ; i < 5;i++)
		List_insert(l,List_end(l),Integer_new(data[i]));

	CU_ASSERT(List_size(l) == 5);

}


void	test_List_isEmpty(){
	List l = List_new();
	CU_ASSERT(List_isEmpty(l) == 1);
}

void 	test_List_print(){
	CU_ASSERT(1);
}

int init_suite1(void){
	return 0;
}

int clean_suite1(void){
	return 0;
}

int main(){
	CU_pSuite pSuite = NULL;

   /* initialize the CUnit test registry */
   if (CUE_SUCCESS != CU_initialize_registry())
		return CU_get_error();

	/* add a suite to the registry */
   pSuite = CU_add_suite("Exercise 2a - List ADT ", init_suite1, clean_suite1);	

	if (NULL == pSuite) {
		CU_cleanup_registry();
		return CU_get_error();
   }

	/* add test to suite */
	if ((NULL == CU_add_test(pSuite, "List_new", test_List_new))){
		CU_cleanup_registry();
      return CU_get_error();
	}
	
	if ((NULL == CU_add_test(pSuite, "List_insert", test_List_insert))){
		CU_cleanup_registry();
      return CU_get_error();
	}
	if ((NULL == CU_add_test(pSuite, "List_free", test_List_free))){
		CU_cleanup_registry();
      return CU_get_error();
	}
	if ((NULL == CU_add_test(pSuite, "List_remove", test_List_remove))){
		CU_cleanup_registry();
      return CU_get_error();
	}

/*
	if ((NULL == CU_add_test(pSuite, "List_elementAt", test_List_elementAt))){
		CU_cleanup_registry();
      return CU_get_error();
	}
	if ((NULL == CU_add_test(pSuite, "List_begin", test_List_begin))){
		CU_cleanup_registry();
      return CU_get_error();
	}
	if ((NULL == CU_add_test(pSuite, "List_end", test_List_end))){
		CU_cleanup_registry();
      return CU_get_error();
	}
	if ((NULL == CU_add_test(pSuite, "List_last", test_List_last))){
		CU_cleanup_registry();
      return CU_get_error();
	}
	if ((NULL == CU_add_test(pSuite, "List_next", test_List_next))){
		CU_cleanup_registry();
      return CU_get_error();
	}
	if ((NULL == CU_add_test(pSuite, "List_prev", test_List_prev))){
		CU_cleanup_registry();
      return CU_get_error();
	}

*/

	if ((NULL == CU_add_test(pSuite, "List_size", test_List_size))){
		CU_cleanup_registry();
      return CU_get_error();
	}
	if ((NULL == CU_add_test(pSuite, "List_isEmpty", test_List_isEmpty))){
		CU_cleanup_registry();
      return CU_get_error();
	}
	if ((NULL == CU_add_test(pSuite, "List_print", test_List_print))){
		CU_cleanup_registry();
      return CU_get_error();
	}


	/* run the tests*/
	CU_basic_set_mode(CU_BRM_VERBOSE);
   CU_basic_run_tests();
   CU_cleanup_registry();
   return CU_get_error();
}
