#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define _USE_ARRAY_LIST_
#include "list.h"

typedef struct _Subject *Subject;

struct _Subject{
	char name[200];
	float grade;
	int units;
};

void print(ElementType element){
	Subject s=(Subject)element;
	printf("%s %1.0d %1.2f\n",s->name,s->units,s->grade);
}

Subject Subject_input(){
	Subject subject = (Subject)malloc(sizeof(struct _Subject));
	printf("Enter subject (NO SPACES): ");
	scanf("%s",subject->name);
	printf("Enter units: ");
	scanf("%d",&(subject->units));
	printf("Enter grade: ");
	scanf("%f",&(subject->grade));
	return subject;
}

int main(){
	List subjects = NULL;
	int i,n;
	ListIterator p;
	Subject s;
	float tunits=0,sum=0;

	subjects = List_new();
	
	printf("How many subjects did you have last sem? ");
	scanf("%d",&n);

	for (i = 1; i <= n; i++){
		List_insert(subjects,List_end(subjects),Subject_input());
	}

	printf("There are %d items on the list.\n ",List_size(subjects));
	puts("\nThe following are the grades you entered.");
	List_print(subjects,print);

	for (p=List_begin(subjects); p != List_end(subjects); p = List_next(p)){
		s = (Subject)List_elementAt(subjects,p);
		tunits += s->units;
		sum += (s->units * s->grade);
	}
	printf("Your GWA is %f \n",sum/tunits);

	return 0;
}

