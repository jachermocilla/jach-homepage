#include <stdlib.h>
#include <stdio.h>

#include "search.h"

int linear_search(int key, int data[], int n){
}

int binary_search(int key, int data[], int n){
}

