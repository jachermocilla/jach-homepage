#include <stdio.h>
#include <CUnit/Basic.h>

#include "search.h"


#define N 100000
#define KEY 100000

int data[N];

void test_linear_search(void){
	int i;
	
	i = linear_search(KEY,data,N);
	CU_ASSERT(i == (KEY - 1));
	
	i = linear_search(KEY+1,data,N);
	CU_ASSERT(i == -1);
}


void test_binary_search(void){
	int i;

	i = binary_search(KEY,data,N);
	CU_ASSERT(i == (KEY - 1));
	
	i = binary_search(KEY+1,data,N);
	CU_ASSERT(i == -1);
}


int init_suite1(void){
	int i;
	for (i = 0; i < N; i++){
		data[i]=i+1;
	}
	return 0;
}

int clean_suite1(void){
	return 0;
}

int main(){
	CU_pSuite pSuite = NULL;

   /* initialize the CUnit test registry */
   if (CUE_SUCCESS != CU_initialize_registry())
		return CU_get_error();

	/* add a suite to the registry */
   pSuite = CU_add_suite("Exercise 1b - Search ", init_suite1, clean_suite1);	

	if (NULL == pSuite) {
		CU_cleanup_registry();
		return CU_get_error();
   }

	/* add test to suite */
	if ((NULL == CU_add_test(pSuite, "Test of linear search", test_linear_search))){
		CU_cleanup_registry();
      return CU_get_error();
	}
	
	if ((NULL == CU_add_test(pSuite, "Test of binary search", test_binary_search))){
		CU_cleanup_registry();
      return CU_get_error();
	}


	/* run the tests*/
	CU_basic_set_mode(CU_BRM_VERBOSE);
   CU_basic_run_tests();
   CU_cleanup_registry();
   return CU_get_error();
}
