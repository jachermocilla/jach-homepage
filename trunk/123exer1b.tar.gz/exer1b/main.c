#include <stdio.h>

#include "search.h"

int main(){
	printf("Write your own tests inside main.c\n");
	return 0;
}
