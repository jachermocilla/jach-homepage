#include <stdlib.h>
#include <stdio.h>

#ifndef __SEARCH_H__
#define __SEARCH_H__

/**
 * Performs linear search for key in array data.
 *
 * @param key 	The number to look for
 * @param data The array of numbers
 * @param n		The number of elements in data
 *
 * @return The index of key in data or -1 if not found. 
 */
int linear_search(int key, int data[], int n);


/**
 * Performs binary search for key in array data
 *
 * @param key 	The number to look for
 * @param data The array of numbers
 * @param n		The number of elements in data
 *
 * @return The index of key in data or -1 if not found. 
 */
int binary_search(int key, int data[], int n);

#endif

